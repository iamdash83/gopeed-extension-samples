[English](README.md) | [中文](README_zh-CN.md)

## Introduction

This sample demonstrates how to build an extension script through the `webpack` project, by installing the third-party dependency `cheerio` to parse the `html` content, it finally realizes an extension that can download all contributor avatars of a specified github repository.

- Showcase

![](.img/example.gif)

## Build

```bash
npm install
npm run build
```


To create a Gopeed extension that downloads all images from a specified Facebook page URL, you can follow these steps:

1. **Understand Gopeed Extension Development**:
    [oai_citation:1,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Gopeed supports extension development using JavaScript, allowing you to enhance its functionality, such as downloading media from websites. [oai_citation:2,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)  [oai_citation:3,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Familiarize yourself with the Gopeed extension development documentation to understand the framework and capabilities. [oai_citation:4,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)  [oai_citation:5,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:6,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

2. **Set Up Your Development Environment**:
   - **Clone the Sample Repository**:  [oai_citation:7,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Begin by cloning the Gopeed extension samples repository to use as a reference. [oai_citation:8,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:9,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
      [oai_citation:10,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)```bash
     git clone https://github.com/GopeedLab/gopeed-extension-samples.git
     ``` [oai_citation:11,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:12,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
   - **Navigate to the Sample Extension**:  [oai_citation:13,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Examine the `github-contributor-avatars-sample` directory to understand how it functions. [oai_citation:14,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:15,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

3. **Create a New Extension**:
   - **Directory Structure**:  [oai_citation:16,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Create a new directory for your extension, e.g., `facebook-image-downloader`. [oai_citation:17,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:18,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
   - **Configuration File**:  [oai_citation:19,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Inside this directory, create a `manifest.json` file to define your extension’s metadata. [oai_citation:20,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:21,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
      [oai_citation:22,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)```json
     {
       “name”: “Facebook Image Downloader”,
       “version”: “1.0”,
       “description”: “Downloads all images from a specified Facebook page URL.”,
       “author”: “Your Name”,
       “homepage”: “https://yourhomepage.com”,
       “match”: [“*://*.facebook.com/*”],
       “executable_path”: “index.js”
     }
     ``` [oai_citation:23,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:24,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

4. **Develop the Extension Logic**:
   - **JavaScript File**:  [oai_citation:25,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Create an `index.js` file in the same directory. This script will handle the extraction and downloading of images. [oai_citation:26,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:27,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
   - **Script Logic**:
     - **Fetch the Page Content**:  [oai_citation:28,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Use JavaScript’s `fetch` API to retrieve the HTML content of the provided Facebook page URL. [oai_citation:29,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:30,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
     - **Parse the HTML**:  [oai_citation:31,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Utilize the DOMParser to parse the fetched HTML content. [oai_citation:32,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:33,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
     - **Extract Image URLs**:  [oai_citation:34,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Select all `<img>` tags and extract their `src` attributes. [oai_citation:35,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:36,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
     - **Download Images**:  [oai_citation:37,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Use Gopeed’s API to download each extracted image URL. [oai_citation:38,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:39,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
      [oai_citation:40,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)```javascript
     async function downloadFacebookImages(pageUrl) {
       try {
         const response = await fetch(pageUrl);
         const html = await response.text();
         const parser = new DOMParser();
         const doc = parser.parseFromString(html, ‘text/html’);
         const imgTags = doc.querySelectorAll(‘img’);
         const imgUrls = Array.from(imgTags).map(img => img.src);
         for (const url of imgUrls) {
           await gopeed.addTask({ url });
         }
         console.log(`Downloaded ${imgUrls.length} images from ${pageUrl}`);
       } catch (error) {
         console.error(‘Error downloading images:’, error);
       }
     }

     // Example usage:
     const facebookPageUrl = ‘https://www.facebook.com/yourpage’;
     downloadFacebookImages(facebookPageUrl);
     ``` [oai_citation:41,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:42,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
     **Note**:  [oai_citation:43,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Replace `’https://www.facebook.com/yourpage’` with the actual Facebook page URL you intend to download images from. [oai_citation:44,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:45,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

5. **Handle Facebook’s Dynamic Content**:
    [oai_citation:46,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Facebook often loads content dynamically, which can make it challenging to fetch all images using a simple HTTP request. [oai_citation:47,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)  [oai_citation:48,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)To address this, consider using a headless browser like Puppeteer to render the page fully before extracting images. [oai_citation:49,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:50,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
    [oai_citation:51,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)```javascript
   const puppeteer = require(‘puppeteer’);

   async function downloadFacebookImages(pageUrl) {
     const browser = await puppeteer.launch();
     const page = await browser.newPage();
     await page.goto(pageUrl, { waitUntil: ‘networkidle2’ });
     const imgUrls = await page.evaluate(() =>
       Array.from(document.querySelectorAll(‘img’)).map(img => img.src)
     );
     for (const url of imgUrls) {
       await gopeed.addTask({ url });
     }
     await browser.close();
     console.log(`Downloaded ${imgUrls.length} images from ${pageUrl}`);
   }

   // Example usage:
   const facebookPageUrl = ‘https://www.facebook.com/yourpage’;
   downloadFacebookImages(facebookPageUrl);
   ``` [oai_citation:52,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:53,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
   **Note**:  [oai_citation:54,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Ensure that Puppeteer is included in your project dependencies and that your environment supports its execution. [oai_citation:55,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:56,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

6. **Testing and Deployment**:
   - **Test Your Extension**:  [oai_citation:57,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Before deploying, thoroughly test your extension to ensure it functions as intended. [oai_citation:58,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:59,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
   - **Package the Extension**:  [oai_citation:60,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Once testing is complete, package your extension according to Gopeed’s guidelines. [oai_citation:61,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:62,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
   - **Installation**:  [oai_citation:63,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Install your extension into Gopeed to start downloading images from Facebook pages. [oai_citation:64,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:65,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

**Important Considerations**:
- **Legal and Ethical Use**:  [oai_citation:66,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Ensure that your use of this extension complies with Facebook’s terms of service and any applicable laws. [oai_citation:67,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:68,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
- **Performance**:  [oai_citation:69,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Downloading a large number of images can consume significant bandwidth and storage. Implement checks to handle such scenarios gracefully. [oai_citation:70,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:71,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)
- **Error Handling**:  [oai_citation:72,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)Implement robust error handling to manage issues like network failures or changes in Facebook’s page structure. [oai_citation:73,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:74,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)

 [oai_citation:75,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata)By following these steps, you can develop a Gopeed extension that efficiently downloads all images from a specified Facebook page URL. [oai_citation:76,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) [oai_citation:77,Error](data:text/plain;charset=utf-8,Unable%20to%20find%20metadata) 